# BOSSNUSILELO KINGDOM

แอป Android ที่มีสิทธิ์ครบถ้วนที่สุดเท่าที่จะทำได้ (รวม 90+ สิทธิ์)

## 📁 โครงสร้างโปรเจกต์

```
BOSSNUSILELO-KINGDOM/
├── build.gradle
├── gradle.properties
├── settings.gradle (สร้างเองเมื่อเปิดใน Android Studio)
└── app/
    ├── build.gradle
    └── src/main/
        ├── AndroidManifest.xml
        ├── java/com/bossnusilelo/kingdom/
        │   ├── MainActivity.java       ← ขอสิทธิ์ runtime
        │   ├── ForegroundService.java  ← service เบื้องหลัง
        │   ├── BadgeReceiver.java      ← notification badge
        │   └── SMSReceiver.java        ← รับ SMS
        └── res/
            ├── drawable/ic_launcher.xml
            └── values/
                ├── strings.xml
                └── themes.xml
```

## 🚀 วิธีเปิดใช้

1. เปิด **Android Studio**
2. เลือก **File → Open** แล้วเลือกโฟลเดอร์ `BOSSNUSILELO-KINGDOM`
3. รอ Gradle sync (อาจต้องดาวน์โหลด dependencies)
4. เปิด **Build → Build APK** หรือรันลงเครื่อง
5. กดปุ่ม **"ขอสิทธิ์ทั้งหมด"** ในแอป

## 🔐 สิทธิ์ที่รวมให้

### สิทธิ์จาก CICI (66 สิทธิ์)
- กล้อง, ไมโครโฟน, ตำแหน่ง, Storage, Notification, Badge, Bluetooth, Biometric, Screen Capture, Sensors

### สิทธิ์เพิ่มเติม (24 สิทธิ์)
- SMS (อ่าน/รับ/ส่ง), โทรศัพท์, ผู้ติดต่อ, ปฏิทิน, ร่างกาย, กิจกรรม
- Overlay (SYSTEM_ALERT_WINDOW), ติดตั้งแอป, ละเว้น Battery
- QUERY_ALL_PACKAGES, MANAGE_EXTERNAL_STORAGE, PACKAGE_USAGE_STATS
- Background Location, NearBy Wifi, และอื่นๆ

## ⚠️ หมายเหตุสำคัญ

1. **สิทธิ์บางตัวต้องขอผ่านหน้าต่างระบบ** (Overlay, Battery, Install) — กดปุ่มในแอปเพื่อเปิด
2. **MANAGE_EXTERNAL_STORAGE / PACKAGE_USAGE_STATS** ต้องเปิดจากหน้า Settings (กดปุ่มจะพาไป)
3. **สิทธิ์ signature-level** (เช่น PRIVACY_BROADCAST) ใช้ได้เฉพาะแอปที่ลงนามด้วย key นี้
4. **Google Play อาจปฏิเสธ** หากขอสิทธิ์มากเกินจำเป็น — แอปนี้เหมาะสำหรับติดตั้งเอง (sideload)
