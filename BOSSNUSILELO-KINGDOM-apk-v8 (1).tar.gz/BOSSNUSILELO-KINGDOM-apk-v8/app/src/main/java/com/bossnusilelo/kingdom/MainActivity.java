package com.bossnusilelo.kingdom;

import android.Manifest;
import android.app.Activity;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.PowerManager;
import android.provider.Settings;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {

    private static final int PERMISSION_REQUEST_CODE = 100;
    private TextView tvStatus;
    private Button btnRequestAll;
    private Button btnRequestOverlay;
    private Button btnStartService;
    private Button btnBattery;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // สร้าง UI แบบง่าย ๆ โดยไม่ต้องใช้ layout XML
        tvStatus = new TextView(this);
        tvStatus.setText("BOSSNUSILELO KINGDOM\n\nแตะปุ่มเพื่อขอสิทธิ์ทั้งหมด");
        tvStatus.setTextSize(18);
        tvStatus.setPadding(32, 32, 32, 32);

        btnRequestAll = new Button(this);
        btnRequestAll.setText("📱 ขอสิทธิ์ทั้งหมด (All Permissions)");
        btnRequestAll.setOnClickListener(v -> requestAllPermissions());

        btnRequestOverlay = new Button(this);
        btnRequestOverlay.setText("🖥️ ขอสิทธิ์แสดงผลทับแอป (Overlay)");
        btnRequestOverlay.setOnClickListener(v -> requestOverlayPermission());

        btnStartService = new Button(this);
        btnStartService.setText("⚙️ เริ่ม Foreground Service");
        btnStartService.setOnClickListener(v -> startForegroundService());

        btnBattery = new Button(this);
        btnBattery.setText("🔋 ขอละเว้น Battery Optimization");
        btnBattery.setOnClickListener(v -> requestIgnoreBatteryOptimizations());

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.addView(tvStatus);
        layout.addView(btnRequestAll);
        layout.addView(btnRequestOverlay);
        layout.addView(btnStartService);
        layout.addView(btnBattery);

        setContentView(layout);

        createNotificationChannel();
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    "default",
                    "Default Channel",
                    NotificationManager.IMPORTANCE_HIGH
            );
            NotificationManager nm = getSystemService(NotificationManager.class);
            nm.createNotificationChannel(channel);
        }
    }

    private void requestAllPermissions() {
        List<String> permissions = new ArrayList<>();

        // สิทธิ์อันตราย (dangerous) ที่ต้องขอแบบ runtime
        permissions.add(Manifest.permission.CAMERA);
        permissions.add(Manifest.permission.RECORD_AUDIO);
        permissions.add(Manifest.permission.ACCESS_FINE_LOCATION);
        permissions.add(Manifest.permission.ACCESS_COARSE_LOCATION);
        permissions.add(Manifest.permission.READ_EXTERNAL_STORAGE);
        permissions.add(Manifest.permission.WRITE_EXTERNAL_STORAGE);
        permissions.add(Manifest.permission.READ_MEDIA_IMAGES);
        permissions.add(Manifest.permission.READ_MEDIA_VIDEO);
        permissions.add(Manifest.permission.READ_MEDIA_AUDIO);
        permissions.add(Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED);
        permissions.add(Manifest.permission.READ_PHONE_STATE);
        permissions.add(Manifest.permission.READ_CONTACTS);
        permissions.add(Manifest.permission.WRITE_CONTACTS);
        permissions.add(Manifest.permission.READ_CALL_LOG);
        permissions.add(Manifest.permission.READ_SMS);
        permissions.add(Manifest.permission.RECEIVE_SMS);
        permissions.add(Manifest.permission.SEND_SMS);
        permissions.add(Manifest.permission.RECEIVE_MMS);
        permissions.add(Manifest.permission.READ_CALENDAR);
        permissions.add(Manifest.permission.WRITE_CALENDAR);
        permissions.add(Manifest.permission.ACTIVITY_RECOGNITION);
        permissions.add(Manifest.permission.BODY_SENSORS);
        permissions.add(Manifest.permission.CALL_PHONE);
        permissions.add(Manifest.permission.USE_BIOMETRIC);
        permissions.add(Manifest.permission.USE_FINGERPRINT);
        permissions.add(Manifest.permission.POST_NOTIFICATIONS);
        permissions.add(Manifest.permission.ACCESS_BACKGROUND_LOCATION);
        permissions.add(Manifest.permission.BLUETOOTH_CONNECT);
        permissions.add(Manifest.permission.BLUETOOTH_SCAN);
        permissions.add(Manifest.permission.BLUETOOTH_ADVERTISE);
        permissions.add(Manifest.permission.NEARBY_WIFI_DEVICES);

        // กรองสิทธิ์ที่ยังไม่ได้ให้
        List<String> toRequest = new ArrayList<>();
        for (String p : permissions) {
            if (ContextCompat.checkSelfPermission(this, p) != PackageManager.PERMISSION_GRANTED) {
                toRequest.add(p);
            }
        }

        if (!toRequest.isEmpty()) {
            ActivityCompat.requestPermissions(this,
                    toRequest.toArray(new String[0]),
                    PERMISSION_REQUEST_CODE);
        } else {
            Toast.makeText(this, "✅ ได้สิทธิ์ทั้งหมดแล้ว!", Toast.LENGTH_LONG).show();
            updateStatus();
        }
    }

    private void requestOverlayPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (!Settings.canDrawOverlays(this)) {
                Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName()));
                startActivity(intent);
            } else {
                Toast.makeText(this, "✅ มีสิทธิ์ Overlay แล้ว", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void requestIgnoreBatteryOptimizations() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
            if (!pm.isIgnoringBatteryOptimizations(getPackageName())) {
                Intent intent = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                        Uri.parse("package:" + getPackageName()));
                startActivity(intent);
            } else {
                Toast.makeText(this, "✅ ละเว้น Battery Optimization แล้ว", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void startForegroundService() {
        Intent intent = new Intent(this, ForegroundService.class);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(intent);
        } else {
            startService(intent);
        }
    }

    private void updateStatus() {
        StringBuilder sb = new StringBuilder();
        sb.append("BOSSNUSILELO KINGDOM\n\nสถานะสิทธิ์:\n");

        String[] perms = {
                Manifest.permission.CAMERA, "กล้อง",
                Manifest.permission.RECORD_AUDIO, "ไมโครโฟน",
                Manifest.permission.ACCESS_FINE_LOCATION, "ตำแหน่ง",
                Manifest.permission.READ_EXTERNAL_STORAGE, "Storage",
                Manifest.permission.POST_NOTIFICATIONS, "แจ้งเตือน"
        };

        for (int i = 0; i < perms.length; i += 2) {
            boolean granted = ContextCompat.checkSelfPermission(this, perms[i])
                    == PackageManager.PERMISSION_GRANTED;
            sb.append("  ").append(perms[i + 1]).append(": ")
              .append(granted ? "✅" : "❌").append("\n");
        }

        tvStatus.setText(sb.toString());
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == PERMISSION_REQUEST_CODE) {
            int granted = 0;
            for (int i = 0; i < grantResults.length; i++) {
                if (grantResults[i] == PackageManager.PERMISSION_GRANTED) granted++;
            }
            Toast.makeText(this,
                    "ได้รับสิทธิ์ " + granted + "/" + grantResults.length + " รายการ",
                    Toast.LENGTH_LONG).show();
            updateStatus();
        }
    }
}
