package com.bossnusilelo.kingdom;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

public class BadgeReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        // จัดการ notification badge บนมือถือหลายยี่ห้อ
        if (intent.getAction() != null &&
                intent.getAction().equals(Intent.ACTION_BOOT_COMPLETED)) {
            // แอปเริ่มทำงานเมื่อเปิดเครื่อง
        }
    }
}
